﻿Imports System.ComponentModel

Public Class frmPerfilVendedor
    Private Sub btnCompras_Click(sender As Object, e As EventArgs)
        frmMisPublicaciones.Show()

    End Sub

    Private Sub btnCancelar2_Click(sender As Object, e As EventArgs) Handles btnCancelar2.Click
        End
    End Sub

    Private Sub btnVender_Click(sender As Object, e As EventArgs) Handles btnVender.Click
        formularioVender.Show()

    End Sub

    Private Sub btnVentas_Click(sender As Object, e As EventArgs) Handles btnVentas.Click
        frmMisPublicaciones.Show()

    End Sub

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click
        Try
            If Me.ValidateChildren And txtNombre2.Text <> String.Empty And txtApellido2.Text <> String.Empty And txtEmail2.Text <> String.Empty And txtCI2.Text <> String.Empty And txtTelefono2.Text <> String.Empty And txtDep2.Text <> String.Empty And txtCiudad2.Text <> String.Empty And txtDomicilio2.Text <> String.Empty And txtCasa2.Text <> String.Empty Then
                MessageBox.Show("Datos correctamente registrados", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Ingrese todos los datos", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtNombre2_Validating(sender As Object, e As CancelEventArgs) Handles txtNombre2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un nombre")

        End If
    End Sub

    Private Sub txtApellido2_Validating(sender As Object, e As CancelEventArgs) Handles txtApellido2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un apellido")

        End If
    End Sub


    Private Sub txtEmail2_Validating(sender As Object, e As CancelEventArgs) Handles txtEmail2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un Email")

        End If
    End Sub

    Private Sub txtCI2_Validating(sender As Object, e As CancelEventArgs) Handles txtCI2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su cedula")

        End If
    End Sub

    Private Sub txtTelefono2_Validating(sender As Object, e As CancelEventArgs) Handles txtTelefono2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un telefono o celular")

        End If
    End Sub

    Private Sub txtDep2_Validating(sender As Object, e As CancelEventArgs) Handles txtDep2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un departamento")

        End If
    End Sub

    Private Sub txtCiudad2_Validating(sender As Object, e As CancelEventArgs) Handles txtCiudad2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese una ciudad")

        End If
    End Sub

    Private Sub txtDomicilio2_Validating(sender As Object, e As CancelEventArgs) Handles txtDomicilio2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un domicilio")

        End If
    End Sub

    Private Sub txtCasa2_Validating(sender As Object, e As CancelEventArgs) Handles txtCasa2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un numero de casa o apt")

        End If
    End Sub

    Private Sub txtNombre2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNombre2.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtApellido2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtApellido2.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub


    Private Sub txtCI2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCI2.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtTelefono2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTelefono2.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtDep2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDep2.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCiudad2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCiudad2.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtDomicilio2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDomicilio2.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCasa2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCasa2.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
End Class