﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdmin
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAdmin))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnAdminProd = New System.Windows.Forms.Button()
        Me.btnAdminUsuarios = New System.Windows.Forms.Button()
        Me.btnVentasVendedor = New System.Windows.Forms.Button()
        Me.btnComprasCliente = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.btnSalir)
        Me.GroupBox2.Controls.Add(Me.btnAdminProd)
        Me.GroupBox2.Controls.Add(Me.btnAdminUsuarios)
        Me.GroupBox2.Controls.Add(Me.btnVentasVendedor)
        Me.GroupBox2.Controls.Add(Me.btnComprasCliente)
        Me.GroupBox2.Font = New System.Drawing.Font("Rubik", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(30, 95)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(320, 196)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Opciones de administrador"
        '
        'btnAdminProd
        '
        Me.btnAdminProd.BackColor = System.Drawing.Color.LightGray
        Me.btnAdminProd.Location = New System.Drawing.Point(46, 31)
        Me.btnAdminProd.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAdminProd.Name = "btnAdminProd"
        Me.btnAdminProd.Size = New System.Drawing.Size(228, 28)
        Me.btnAdminProd.TabIndex = 2
        Me.btnAdminProd.Text = "Administrar productos"
        Me.btnAdminProd.UseVisualStyleBackColor = False
        '
        'btnAdminUsuarios
        '
        Me.btnAdminUsuarios.BackColor = System.Drawing.Color.LightGray
        Me.btnAdminUsuarios.Location = New System.Drawing.Point(46, 64)
        Me.btnAdminUsuarios.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAdminUsuarios.Name = "btnAdminUsuarios"
        Me.btnAdminUsuarios.Size = New System.Drawing.Size(228, 28)
        Me.btnAdminUsuarios.TabIndex = 3
        Me.btnAdminUsuarios.Text = "Administrar usuarios  "
        Me.btnAdminUsuarios.UseVisualStyleBackColor = False
        '
        'btnVentasVendedor
        '
        Me.btnVentasVendedor.BackColor = System.Drawing.Color.LightGray
        Me.btnVentasVendedor.Location = New System.Drawing.Point(46, 131)
        Me.btnVentasVendedor.Margin = New System.Windows.Forms.Padding(2)
        Me.btnVentasVendedor.Name = "btnVentasVendedor"
        Me.btnVentasVendedor.Size = New System.Drawing.Size(228, 28)
        Me.btnVentasVendedor.TabIndex = 5
        Me.btnVentasVendedor.Text = "Ver todas las ventas de un vendedor"
        Me.btnVentasVendedor.UseVisualStyleBackColor = False
        '
        'btnComprasCliente
        '
        Me.btnComprasCliente.BackColor = System.Drawing.Color.LightGray
        Me.btnComprasCliente.Location = New System.Drawing.Point(46, 98)
        Me.btnComprasCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.btnComprasCliente.Name = "btnComprasCliente"
        Me.btnComprasCliente.Size = New System.Drawing.Size(228, 28)
        Me.btnComprasCliente.TabIndex = 4
        Me.btnComprasCliente.Text = "Ver todas las compras de un cliente"
        Me.btnComprasCliente.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightGray
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(30, 35)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(320, 55)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.LightGray
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(43, 15)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(250, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Bienvenido Administrador"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-1, -2)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(390, 334)
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'btnSalir
        '
        Me.btnSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalir.Location = New System.Drawing.Point(240, 168)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(75, 23)
        Me.btnSalir.TabIndex = 27
        Me.btnSalir.Text = "Salir"
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'frmAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(384, 330)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmAdmin"
        Me.Text = "Perfil_admin"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnAdminProd As Button
    Friend WithEvents btnAdminUsuarios As Button
    Friend WithEvents btnVentasVendedor As Button
    Friend WithEvents btnComprasCliente As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnSalir As Button
End Class
