﻿Imports System.ComponentModel

Public Class frmContraseña
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End

    End Sub

    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click
        Try
            If Me.ValidateChildren And txtEmail.Text <> String.Empty And txtCont.Text <> String.Empty And txtCont2.Text <> String.Empty Then
                MessageBox.Show("Datos correctamente ingresados", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information)
                frmIngreso.Show()
            Else
                MessageBox.Show("Ingrese todos los datos", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtEmail_Validating(sender As Object, e As CancelEventArgs) Handles txtEmail.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su Email")

        End If
    End Sub

    Private Sub txtCont_Validating(sender As Object, e As CancelEventArgs) Handles txtCont.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su contraseña")

        End If
    End Sub

    Private Sub txtCont2_Validating(sender As Object, e As CancelEventArgs) Handles txtCont2.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Repita su contraseña")

        End If
    End Sub
End Class