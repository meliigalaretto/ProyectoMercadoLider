﻿Public Class frmProducto
    Private Sub btnComprar_Click(sender As Object, e As EventArgs) Handles btnComprar.Click
        frmComprar.Show()

    End Sub
End Class