﻿Imports System.ComponentModel

Public Class formularioVender
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles frmVender.Click
        End
    End Sub

    Private Sub btnPublicar_Click(sender As Object, e As EventArgs) Handles btnPublicar.Click
        If txtArticulo.Text = "" Or txtDescripcion.Text = "" Or cmbCategoria.Text = "" Or txtPrecio.Text = "" Then
            MsgBox("Ha ocurrido un error, porfavor llena los campos correspondientes", MsgBoxStyle.Critical + vbOK)
        Else
            MsgBox("Datos ingresados correctamente")
        End If

    End Sub

    Private Sub cmbCategoria_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbCategoria.SelectedIndexChanged

    End Sub
End Class