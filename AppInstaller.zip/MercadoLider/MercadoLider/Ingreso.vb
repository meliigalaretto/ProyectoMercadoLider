﻿Imports System.ComponentModel

Public Class frmIngreso
    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        Try
            If Me.ValidateChildren And txtEmail.Text <> String.Empty And txtContraseña.Text <> String.Empty Then
                MessageBox.Show("Datos correctamente ingresados", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information)
                frmMenu2.Show()
            Else
                MessageBox.Show("Ingrese todos los datos", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub txtEmail_Validating(sender As Object, e As CancelEventArgs) Handles txtEmail.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un Email")

        End If
    End Sub

    Private Sub txtContraseña_Validating(sender As Object, e As CancelEventArgs) Handles txtContraseña.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su contraseña")

        End If
    End Sub
    Private Sub lblContraseña_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblContraseña.LinkClicked
        frmContraseña.Show()


    End Sub
End Class