﻿Imports System.ComponentModel

Public Class frmPerfilCliente
    Private Sub btnCompras_Click(sender As Object, e As EventArgs) Handles btnCompras.Click
        frmMisCompras.Show()

    End Sub

    Private Sub btnCancelar2_Click(sender As Object, e As EventArgs) Handles btnCancelar2.Click
        End

    End Sub

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click
        Try
            If Me.ValidateChildren And txtNombre3.Text <> String.Empty And txtApellido3.Text <> String.Empty And txtEmail3.Text <> String.Empty And txtCI3.Text <> String.Empty And txtTelefono3.Text <> String.Empty And txtDep3.Text <> String.Empty And txtCiudad3.Text <> String.Empty And txtDomicilio3.Text <> String.Empty And txtCasa3.Text <> String.Empty Then
                MessageBox.Show("Datos correctamente registrados", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Ingrese todos los datos", "Registro de usuarios", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtNombre3_Validating(sender As Object, e As CancelEventArgs) Handles txtNombre3.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un nombre")

        End If
    End Sub

    Private Sub txtApellido3_Validating(sender As Object, e As CancelEventArgs) Handles txtApellido3.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un apellido")

        End If
    End Sub

    Private Sub txtEmail3_Validating(sender As Object, e As CancelEventArgs) Handles txtEmail3.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un Email")

        End If
    End Sub

    Private Sub txtCI3_Validating(sender As Object, e As CancelEventArgs) Handles txtCI3.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese su cedula")

        End If
    End Sub

    Private Sub txtTelefono3_Validating(sender As Object, e As CancelEventArgs) Handles txtTelefono3.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un telefono o celular")

        End If
    End Sub

    Private Sub txtDep3_Validating(sender As Object, e As CancelEventArgs) Handles txtDep3.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un departamento")

        End If
    End Sub

    Private Sub txtCiudad3_Validating(sender As Object, e As CancelEventArgs) Handles txtCiudad3.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese una ciudad")

        End If
    End Sub

    Private Sub txtDomicilio3_Validating(sender As Object, e As CancelEventArgs) Handles txtDomicilio3.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un domicilio")

        End If
    End Sub

    Private Sub txtCasa3_Validating(sender As Object, e As CancelEventArgs) Handles txtCasa3.Validating
        If DirectCast(sender, TextBox).Text.Length > 0 Then
            Me.btnError.SetError(sender, "")
        Else
            Me.btnError.SetError(sender, "Ingrese un numero de casa o apt")

        End If
    End Sub

    Private Sub txtNombre3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNombre3.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtApellido3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtApellido3.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCI3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCI3.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtTelefono3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTelefono3.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtDep3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDep3.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCiudad3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCiudad3.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtDomicilio3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDomicilio3.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub txtCasa3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCasa3.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
End Class