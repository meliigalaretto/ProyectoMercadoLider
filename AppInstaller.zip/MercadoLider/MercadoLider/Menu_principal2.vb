﻿Public Class frmMenu2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmPerfilCliente.Show()
        frmPerfilVendedor.Show()

    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        frmBuscador2.Show()

    End Sub

    Private Sub btnAdmin_Click(sender As Object, e As EventArgs) Handles btnAdmin.Click
        frmAdministrador.Show()

    End Sub
End Class