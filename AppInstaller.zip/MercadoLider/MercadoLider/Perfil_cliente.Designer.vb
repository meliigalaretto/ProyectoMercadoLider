﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPerfilCliente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPerfilCliente))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtApellido3 = New System.Windows.Forms.TextBox()
        Me.txtNombre3 = New System.Windows.Forms.TextBox()
        Me.txtEmail3 = New System.Windows.Forms.TextBox()
        Me.txtCI3 = New System.Windows.Forms.TextBox()
        Me.txtTelefono3 = New System.Windows.Forms.TextBox()
        Me.txtDep3 = New System.Windows.Forms.TextBox()
        Me.txtCiudad3 = New System.Windows.Forms.TextBox()
        Me.txtDomicilio3 = New System.Windows.Forms.TextBox()
        Me.txtCasa3 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnCancelar2 = New System.Windows.Forms.Button()
        Me.btnGuardar = New System.Windows.Forms.Button()
        Me.btnEditar = New System.Windows.Forms.Button()
        Me.btnFoto = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnCompras = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pctFotoPerfil = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.btnError = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.pctFotoPerfil, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnError, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.txtApellido3)
        Me.GroupBox2.Controls.Add(Me.txtNombre3)
        Me.GroupBox2.Controls.Add(Me.txtEmail3)
        Me.GroupBox2.Controls.Add(Me.txtCI3)
        Me.GroupBox2.Controls.Add(Me.txtTelefono3)
        Me.GroupBox2.Controls.Add(Me.txtDep3)
        Me.GroupBox2.Controls.Add(Me.txtCiudad3)
        Me.GroupBox2.Controls.Add(Me.txtDomicilio3)
        Me.GroupBox2.Controls.Add(Me.txtCasa3)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(168, 37)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(404, 333)
        Me.GroupBox2.TabIndex = 14
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Datos personales:"
        '
        'txtApellido3
        '
        Me.txtApellido3.Location = New System.Drawing.Point(109, 66)
        Me.txtApellido3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtApellido3.Name = "txtApellido3"
        Me.txtApellido3.Size = New System.Drawing.Size(187, 21)
        Me.txtApellido3.TabIndex = 39
        '
        'txtNombre3
        '
        Me.txtNombre3.Location = New System.Drawing.Point(109, 37)
        Me.txtNombre3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtNombre3.Name = "txtNombre3"
        Me.txtNombre3.Size = New System.Drawing.Size(187, 21)
        Me.txtNombre3.TabIndex = 38
        '
        'txtEmail3
        '
        Me.txtEmail3.Location = New System.Drawing.Point(109, 97)
        Me.txtEmail3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEmail3.Name = "txtEmail3"
        Me.txtEmail3.Size = New System.Drawing.Size(187, 21)
        Me.txtEmail3.TabIndex = 37
        '
        'txtCI3
        '
        Me.txtCI3.Location = New System.Drawing.Point(109, 127)
        Me.txtCI3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCI3.Name = "txtCI3"
        Me.txtCI3.Size = New System.Drawing.Size(187, 21)
        Me.txtCI3.TabIndex = 36
        '
        'txtTelefono3
        '
        Me.txtTelefono3.Location = New System.Drawing.Point(109, 157)
        Me.txtTelefono3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTelefono3.Name = "txtTelefono3"
        Me.txtTelefono3.Size = New System.Drawing.Size(187, 21)
        Me.txtTelefono3.TabIndex = 35
        '
        'txtDep3
        '
        Me.txtDep3.Location = New System.Drawing.Point(109, 186)
        Me.txtDep3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDep3.Name = "txtDep3"
        Me.txtDep3.Size = New System.Drawing.Size(187, 21)
        Me.txtDep3.TabIndex = 34
        '
        'txtCiudad3
        '
        Me.txtCiudad3.Location = New System.Drawing.Point(109, 214)
        Me.txtCiudad3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCiudad3.Name = "txtCiudad3"
        Me.txtCiudad3.Size = New System.Drawing.Size(187, 21)
        Me.txtCiudad3.TabIndex = 33
        '
        'txtDomicilio3
        '
        Me.txtDomicilio3.Location = New System.Drawing.Point(109, 243)
        Me.txtDomicilio3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDomicilio3.Name = "txtDomicilio3"
        Me.txtDomicilio3.Size = New System.Drawing.Size(187, 21)
        Me.txtDomicilio3.TabIndex = 32
        '
        'txtCasa3
        '
        Me.txtCasa3.Location = New System.Drawing.Point(109, 272)
        Me.txtCasa3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCasa3.Name = "txtCasa3"
        Me.txtCasa3.Size = New System.Drawing.Size(187, 21)
        Me.txtCasa3.TabIndex = 31
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(32, 243)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(62, 15)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Domicilio:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(18, 274)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 15)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "N° casa, apt:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(44, 216)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 15)
        Me.Label7.TabIndex = 28
        Me.Label7.Text = "Ciudad:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(8, 185)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 15)
        Me.Label6.TabIndex = 27
        Me.Label6.Text = "Departamento:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(35, 156)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 15)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "Teléfono:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(20, 127)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 15)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Documento:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(47, 97)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 15)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "E-mail:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(40, 66)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 15)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Apellido:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(38, 37)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(55, 15)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Nombre:"
        '
        'btnCancelar2
        '
        Me.btnCancelar2.BackColor = System.Drawing.SystemColors.Control
        Me.btnCancelar2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelar2.Location = New System.Drawing.Point(498, 374)
        Me.btnCancelar2.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCancelar2.Name = "btnCancelar2"
        Me.btnCancelar2.Size = New System.Drawing.Size(74, 26)
        Me.btnCancelar2.TabIndex = 17
        Me.btnCancelar2.Text = "Cancelar"
        Me.btnCancelar2.UseVisualStyleBackColor = False
        '
        'btnGuardar
        '
        Me.btnGuardar.BackColor = System.Drawing.SystemColors.Control
        Me.btnGuardar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGuardar.Location = New System.Drawing.Point(420, 374)
        Me.btnGuardar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnGuardar.Name = "btnGuardar"
        Me.btnGuardar.Size = New System.Drawing.Size(74, 26)
        Me.btnGuardar.TabIndex = 16
        Me.btnGuardar.Text = "Guardar"
        Me.btnGuardar.UseVisualStyleBackColor = False
        '
        'btnEditar
        '
        Me.btnEditar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditar.Location = New System.Drawing.Point(508, 19)
        Me.btnEditar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnEditar.Name = "btnEditar"
        Me.btnEditar.Size = New System.Drawing.Size(64, 19)
        Me.btnEditar.TabIndex = 15
        Me.btnEditar.Text = "Editar"
        Me.btnEditar.UseVisualStyleBackColor = True
        '
        'btnFoto
        '
        Me.btnFoto.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnFoto.Location = New System.Drawing.Point(11, 164)
        Me.btnFoto.Margin = New System.Windows.Forms.Padding(2)
        Me.btnFoto.Name = "btnFoto"
        Me.btnFoto.Size = New System.Drawing.Size(141, 19)
        Me.btnFoto.TabIndex = 13
        Me.btnFoto.Text = "Cambiar foto"
        Me.btnFoto.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.btnCompras)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(3, 198)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(149, 91)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Compras"
        '
        'btnCompras
        '
        Me.btnCompras.BackColor = System.Drawing.Color.LightGray
        Me.btnCompras.Location = New System.Drawing.Point(8, 34)
        Me.btnCompras.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCompras.Name = "btnCompras"
        Me.btnCompras.Size = New System.Drawing.Size(137, 27)
        Me.btnCompras.TabIndex = 4
        Me.btnCompras.Text = "Ver mis compras"
        Me.btnCompras.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label1.Location = New System.Drawing.Point(13, 22)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Foto de perfil"
        '
        'pctFotoPerfil
        '
        Me.pctFotoPerfil.BackColor = System.Drawing.Color.White
        Me.pctFotoPerfil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pctFotoPerfil.Location = New System.Drawing.Point(11, 37)
        Me.pctFotoPerfil.Margin = New System.Windows.Forms.Padding(2)
        Me.pctFotoPerfil.Name = "pctFotoPerfil"
        Me.pctFotoPerfil.Size = New System.Drawing.Size(141, 122)
        Me.pctFotoPerfil.TabIndex = 10
        Me.pctFotoPerfil.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.SystemColors.Control
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(0, -2)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(618, 440)
        Me.PictureBox2.TabIndex = 18
        Me.PictureBox2.TabStop = False
        '
        'btnError
        '
        Me.btnError.ContainerControl = Me
        '
        'frmPerfilCliente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(615, 435)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnCancelar2)
        Me.Controls.Add(Me.btnGuardar)
        Me.Controls.Add(Me.btnEditar)
        Me.Controls.Add(Me.btnFoto)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pctFotoPerfil)
        Me.Controls.Add(Me.PictureBox2)
        Me.Name = "frmPerfilCliente"
        Me.Text = "Perfil_cliente"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.pctFotoPerfil, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnError, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtApellido3 As TextBox
    Friend WithEvents txtNombre3 As TextBox
    Friend WithEvents txtEmail3 As TextBox
    Friend WithEvents txtCI3 As TextBox
    Friend WithEvents txtTelefono3 As TextBox
    Friend WithEvents txtDep3 As TextBox
    Friend WithEvents txtCiudad3 As TextBox
    Friend WithEvents txtDomicilio3 As TextBox
    Friend WithEvents txtCasa3 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents btnCancelar2 As Button
    Friend WithEvents btnGuardar As Button
    Friend WithEvents btnEditar As Button
    Friend WithEvents btnFoto As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnCompras As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents pctFotoPerfil As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btnError As ErrorProvider
End Class
