﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPerfilVendedor
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPerfilVendedor))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtApellido2 = New System.Windows.Forms.TextBox()
        Me.txtNombre2 = New System.Windows.Forms.TextBox()
        Me.txtEmail2 = New System.Windows.Forms.TextBox()
        Me.txtCI2 = New System.Windows.Forms.TextBox()
        Me.txtTelefono2 = New System.Windows.Forms.TextBox()
        Me.txtDep2 = New System.Windows.Forms.TextBox()
        Me.txtCiudad2 = New System.Windows.Forms.TextBox()
        Me.txtDomicilio2 = New System.Windows.Forms.TextBox()
        Me.txtCasa2 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnCancelar2 = New System.Windows.Forms.Button()
        Me.btnGuardar = New System.Windows.Forms.Button()
        Me.btnEditar = New System.Windows.Forms.Button()
        Me.btnFoto = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnVentas = New System.Windows.Forms.Button()
        Me.btnVender = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pctFotoPerfil = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnError = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.pctFotoPerfil, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnError, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.txtApellido2)
        Me.GroupBox2.Controls.Add(Me.txtNombre2)
        Me.GroupBox2.Controls.Add(Me.txtEmail2)
        Me.GroupBox2.Controls.Add(Me.txtCI2)
        Me.GroupBox2.Controls.Add(Me.txtTelefono2)
        Me.GroupBox2.Controls.Add(Me.txtDep2)
        Me.GroupBox2.Controls.Add(Me.txtCiudad2)
        Me.GroupBox2.Controls.Add(Me.txtDomicilio2)
        Me.GroupBox2.Controls.Add(Me.txtCasa2)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(176, 35)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(406, 333)
        Me.GroupBox2.TabIndex = 22
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Datos personales:"
        '
        'txtApellido2
        '
        Me.txtApellido2.Location = New System.Drawing.Point(108, 63)
        Me.txtApellido2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtApellido2.Name = "txtApellido2"
        Me.txtApellido2.Size = New System.Drawing.Size(197, 21)
        Me.txtApellido2.TabIndex = 39
        '
        'txtNombre2
        '
        Me.txtNombre2.Location = New System.Drawing.Point(108, 34)
        Me.txtNombre2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtNombre2.Name = "txtNombre2"
        Me.txtNombre2.Size = New System.Drawing.Size(197, 21)
        Me.txtNombre2.TabIndex = 38
        '
        'txtEmail2
        '
        Me.txtEmail2.Location = New System.Drawing.Point(108, 94)
        Me.txtEmail2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtEmail2.Name = "txtEmail2"
        Me.txtEmail2.Size = New System.Drawing.Size(197, 21)
        Me.txtEmail2.TabIndex = 37
        '
        'txtCI2
        '
        Me.txtCI2.Location = New System.Drawing.Point(108, 124)
        Me.txtCI2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCI2.Name = "txtCI2"
        Me.txtCI2.Size = New System.Drawing.Size(197, 21)
        Me.txtCI2.TabIndex = 36
        '
        'txtTelefono2
        '
        Me.txtTelefono2.Location = New System.Drawing.Point(108, 154)
        Me.txtTelefono2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTelefono2.Name = "txtTelefono2"
        Me.txtTelefono2.Size = New System.Drawing.Size(197, 21)
        Me.txtTelefono2.TabIndex = 35
        '
        'txtDep2
        '
        Me.txtDep2.Location = New System.Drawing.Point(108, 183)
        Me.txtDep2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDep2.Name = "txtDep2"
        Me.txtDep2.Size = New System.Drawing.Size(197, 21)
        Me.txtDep2.TabIndex = 34
        '
        'txtCiudad2
        '
        Me.txtCiudad2.Location = New System.Drawing.Point(108, 211)
        Me.txtCiudad2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCiudad2.Name = "txtCiudad2"
        Me.txtCiudad2.Size = New System.Drawing.Size(197, 21)
        Me.txtCiudad2.TabIndex = 33
        '
        'txtDomicilio2
        '
        Me.txtDomicilio2.Location = New System.Drawing.Point(108, 240)
        Me.txtDomicilio2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDomicilio2.Name = "txtDomicilio2"
        Me.txtDomicilio2.Size = New System.Drawing.Size(197, 21)
        Me.txtDomicilio2.TabIndex = 32
        '
        'txtCasa2
        '
        Me.txtCasa2.Location = New System.Drawing.Point(108, 269)
        Me.txtCasa2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtCasa2.Name = "txtCasa2"
        Me.txtCasa2.Size = New System.Drawing.Size(197, 21)
        Me.txtCasa2.TabIndex = 31
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(32, 243)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(62, 15)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Domicilio:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(18, 274)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 15)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "N° casa, apt:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(44, 216)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 15)
        Me.Label7.TabIndex = 28
        Me.Label7.Text = "Ciudad:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(8, 185)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 15)
        Me.Label6.TabIndex = 27
        Me.Label6.Text = "Departamento:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(35, 156)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 15)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "Teléfono:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(20, 127)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 15)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Documento:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(47, 97)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 15)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "E-mail:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(40, 63)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 15)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Apellido:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(38, 37)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(55, 15)
        Me.Label10.TabIndex = 22
        Me.Label10.Text = "Nombre:"
        '
        'btnCancelar2
        '
        Me.btnCancelar2.BackColor = System.Drawing.SystemColors.Control
        Me.btnCancelar2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelar2.Location = New System.Drawing.Point(508, 372)
        Me.btnCancelar2.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCancelar2.Name = "btnCancelar2"
        Me.btnCancelar2.Size = New System.Drawing.Size(74, 26)
        Me.btnCancelar2.TabIndex = 25
        Me.btnCancelar2.Text = "Cancelar"
        Me.btnCancelar2.UseVisualStyleBackColor = False
        '
        'btnGuardar
        '
        Me.btnGuardar.BackColor = System.Drawing.SystemColors.Control
        Me.btnGuardar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGuardar.Location = New System.Drawing.Point(430, 372)
        Me.btnGuardar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnGuardar.Name = "btnGuardar"
        Me.btnGuardar.Size = New System.Drawing.Size(74, 26)
        Me.btnGuardar.TabIndex = 24
        Me.btnGuardar.Text = "Guardar"
        Me.btnGuardar.UseVisualStyleBackColor = False
        '
        'btnEditar
        '
        Me.btnEditar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditar.Location = New System.Drawing.Point(518, 17)
        Me.btnEditar.Margin = New System.Windows.Forms.Padding(2)
        Me.btnEditar.Name = "btnEditar"
        Me.btnEditar.Size = New System.Drawing.Size(64, 19)
        Me.btnEditar.TabIndex = 23
        Me.btnEditar.Text = "Editar"
        Me.btnEditar.UseVisualStyleBackColor = True
        '
        'btnFoto
        '
        Me.btnFoto.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnFoto.Location = New System.Drawing.Point(13, 164)
        Me.btnFoto.Margin = New System.Windows.Forms.Padding(2)
        Me.btnFoto.Name = "btnFoto"
        Me.btnFoto.Size = New System.Drawing.Size(139, 19)
        Me.btnFoto.TabIndex = 21
        Me.btnFoto.Text = "Cambiar foto"
        Me.btnFoto.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.btnVentas)
        Me.GroupBox1.Controls.Add(Me.btnVender)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(13, 198)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(145, 126)
        Me.GroupBox1.TabIndex = 20
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Ventas"
        '
        'btnVentas
        '
        Me.btnVentas.Location = New System.Drawing.Point(6, 35)
        Me.btnVentas.Name = "btnVentas"
        Me.btnVentas.Size = New System.Drawing.Size(134, 24)
        Me.btnVentas.TabIndex = 41
        Me.btnVentas.Text = "Ver mis ventas"
        Me.btnVentas.UseVisualStyleBackColor = True
        '
        'btnVender
        '
        Me.btnVender.Location = New System.Drawing.Point(4, 74)
        Me.btnVender.Name = "btnVender"
        Me.btnVender.Size = New System.Drawing.Size(137, 24)
        Me.btnVender.TabIndex = 40
        Me.btnVender.Text = "Publicar artículo"
        Me.btnVender.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Label1.Location = New System.Drawing.Point(14, 20)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Foto de perfil"
        '
        'pctFotoPerfil
        '
        Me.pctFotoPerfil.BackColor = System.Drawing.Color.White
        Me.pctFotoPerfil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pctFotoPerfil.Location = New System.Drawing.Point(13, 35)
        Me.pctFotoPerfil.Margin = New System.Windows.Forms.Padding(2)
        Me.pctFotoPerfil.Name = "pctFotoPerfil"
        Me.pctFotoPerfil.Size = New System.Drawing.Size(145, 124)
        Me.pctFotoPerfil.TabIndex = 18
        Me.pctFotoPerfil.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-1, -2)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(603, 435)
        Me.PictureBox1.TabIndex = 26
        Me.PictureBox1.TabStop = False
        '
        'btnError
        '
        Me.btnError.ContainerControl = Me
        '
        'frmPerfilVendedor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(601, 433)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnCancelar2)
        Me.Controls.Add(Me.btnGuardar)
        Me.Controls.Add(Me.btnEditar)
        Me.Controls.Add(Me.btnFoto)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pctFotoPerfil)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmPerfilVendedor"
        Me.Text = "Perfil_vendedor"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.pctFotoPerfil, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnError, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtApellido2 As TextBox
    Friend WithEvents txtNombre2 As TextBox
    Friend WithEvents txtEmail2 As TextBox
    Friend WithEvents txtCI2 As TextBox
    Friend WithEvents txtTelefono2 As TextBox
    Friend WithEvents txtDep2 As TextBox
    Friend WithEvents txtCiudad2 As TextBox
    Friend WithEvents txtDomicilio2 As TextBox
    Friend WithEvents txtCasa2 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents btnCancelar2 As Button
    Friend WithEvents btnGuardar As Button
    Friend WithEvents btnEditar As Button
    Friend WithEvents btnFoto As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents pctFotoPerfil As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnVentas As Button
    Friend WithEvents btnVender As Button
    Friend WithEvents btnError As ErrorProvider
End Class
