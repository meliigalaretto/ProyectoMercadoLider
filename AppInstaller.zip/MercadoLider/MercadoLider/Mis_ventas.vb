﻿Public Class frmMisPublicaciones
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub

    Private Sub btnEditar_Click(sender As Object, e As EventArgs) Handles btnEditar.Click
        frmEditar.Show()

    End Sub

    Private Sub btnEditar2_Click(sender As Object, e As EventArgs) Handles btnEditar2.Click
        frmEditar.Show()

    End Sub
End Class