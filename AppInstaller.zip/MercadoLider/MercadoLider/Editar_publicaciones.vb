﻿Public Class frmEditar
    Private Sub btnPublicar_Click(sender As Object, e As EventArgs) Handles btnPublicar.Click
        If txtArticulo.Text = "" Or txtDescripcion.Text = "" Or cmbCategoria.Text = "" Or txtPrecio.Text = "" Then
            MsgBox("Ha ocurrido un error, porfavor llena los campos correspondientes", MsgBoxStyle.Critical + vbOK)
        Else
            MsgBox("Datos ingresados correctamente")
        End If
    End Sub
End Class